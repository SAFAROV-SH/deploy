import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Home from './components/Home';
import Referral from './components/Referral';
import Tasks from './components/Tasks';
import Withdraw from './components/Withdraw';
import Navbar from './components/Navbar';
import UcShop from './components/Ucshop';
const App = () => {
  return (
    <div className="mobile-app">
      <div className="main-content">
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/referral" element={<Referral />} />
          <Route path="/tasks" element={<Tasks />} />
          <Route path="/withdraw" element={<Withdraw />} />
          <Route path="/ucshop" element={<UcShop />} />
        </Routes>
      </div>
    </div>
  );
};

export default App;