import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

const Navbar = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [activeItem, setActiveItem] = useState('/');

  useEffect(() => {
    // LocalStorage dan oldingi aktiv sahifani olish
    const savedActiveItem = localStorage.getItem('activeItem');
    if (savedActiveItem) {
      setActiveItem(savedActiveItem);
    } else {
      setActiveItem(location.pathname);
    }
  }, [location.pathname]);

  const handleMenuClick = (path) => {
    setActiveItem(path); 
    localStorage.setItem('activeItem', path); // Aktiv sahifani saqlash
    navigate(path);
  };

  return (
    <div className="sticky-nav">
      <button 
        className={`nav-item ${activeItem === '/ucshop' ? 'active' : ''}`} 
        onClick={() => handleMenuClick('/ucshop')}
      >
        <i className="fas fa-shopping-cart"></i>
        <span>Uc servis</span>
      </button>
      <button 
        className={`nav-item ${activeItem === '/referral' ? 'active' : ''}`} 
        onClick={() => handleMenuClick('/referral')}
      >
        <i className="fas fa-user-plus"></i>
        <span>Referal</span>
      </button>
      <button 
        className={`nav-item ${activeItem === '/' ? 'active' : ''}`} 
        onClick={() => handleMenuClick('/')}
      >
        <i className="fas fa-gift"></i>
        <span>Bonus</span>
      </button>
      <button 
        className={`nav-item ${activeItem === '/tasks' ? 'active' : ''}`} 
        onClick={() => handleMenuClick('/tasks')}
      >
        <i className="fas fa-tasks"></i>
        <span>Vazifalar</span>
      </button> 
      <button 
        className={`nav-item ${activeItem === '/withdraw' ? 'active' : ''}`} 
        onClick={() => handleMenuClick('/withdraw')}
      >
        <i className="fas fa-wallet"></i>
        <span>Hisob</span>
      </button>
    </div>
  );
};

export default Navbar;
