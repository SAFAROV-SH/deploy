import '../css/Header.css';

const Header = () => {
  return (
    <div className="game-header">
      <div className="user-info">
        <div className="profile-image">
          <img src="https://cdn.midasbuy.com/images/apps/pubgm/1599546007887MVeNUtB6.png" alt="Profile" />
        </div>
        <div className="username">
          <span className="username-text">『 SAFAROV_SH 』</span>
        </div>
      </div>
      <div className="balance-info">
        <div className="currency-icon">
          <img src="https://cdn.midasbuy.com/images/uc-small.bc30c95b.png" alt="UC" />
        </div>
        <div className="balance-amount">32.50 UC</div>
      </div>
    </div>
  );
};

export default Header;