import { motion } from "framer-motion";
import "../css/shop.css";
// import Header from "./Header";

const cardVariants = {
  hidden: (index) => ({
    x: index % 2 === 0 ? -100 : 100,
    opacity: 0,
  }),
  visible: (index) => ({
    x: 0,
    opacity: 1,
    transition: { duration: 0.5, ease: "easeOut", delay: index * 0.1 },
  }),
};

const popularTagVariants = {
  animate: {
    backgroundColor: ["#FFD700", "#FF6347", "#FF4500", "#FFD700"], // Oltin -> Qizil -> Yorqin apelsin -> Oltin
    transition: {
      duration: 2,
      repeat: Infinity,
      repeatType: "reverse",
      ease: "easeInOut",
    },
  },
};

const UcShop = () => {
  const data = [
    {
      id: 1,
      mainAmount: 30,
      bonusAmount: 0,
      price: 6000,
      currency: "so'm",
      oldPrice: 0.6,
      popular: false,
      image: "https://cdn.midasbuy.com/images/apps/pubgm/1599546007887MVeNUtB6.png"
    },
    {
        id: 2,
        mainAmount: 60,
        bonusAmount: 0,
        price: 13000,
        currency: "so'm",
        oldPrice: 1,
        popular: false,
        image: "https://cdn.midasbuy.com/images/apps/pubgm/1599546007887MVeNUtB6.png"
      },
    {
        id: 3,
        mainAmount: 120,
        bonusAmount: 0,
        price: 24900,
        currency: "so'm",
        oldPrice: 0.6,
        popular: false,
        image: "https://cdn.midasbuy.com/images/apps/pubgm/1599546030876PIvqwGaa.png"
      },
      {
        id: 4,
        mainAmount: 180,
        bonusAmount: 0,
        price: 37900,
        currency: "so'm",
        oldPrice: 0.6,
        popular: false,
        image: "https://cdn.midasbuy.com/images/apps/pubgm/1599546041426W8hmErMS.png"
      },
      {
        id: 5,
        mainAmount: 325,
        bonusAmount: 0,
        price: 57900,
        currency: "so'm",
        oldPrice: 1,
        popular: true,
        image: "https://cdn.midasbuy.com/images/apps/pubgm/1599546052747L5gSu7VB.png"
      },
      {
        id: 6,
        mainAmount: 385,
        bonusAmount: 0,
        price: 69900,
        currency: "so'm",
        oldPrice: 1,
        popular: false,
        image: "https://cdn.midasbuy.com/images/apps/pubgm/1599546061912PLgMlY23.png"
      },
      {
        id: 7,
        mainAmount: 660,
        bonusAmount: 0,
        price: 115000,
        currency: "so'm",
        oldPrice: 1,
        popular: false,
        image: "https://cdn.midasbuy.com/images/apps/pubgm/1599546071746KqkIhrzG.png"
      },
      {
        id: 8,
        mainAmount: 720,
        bonusAmount: 0,
        price: 125000,
        currency: "so'm",
        oldPrice: 1,
        popular: false,
        image: "https://cdn.midasbuy.com/images/apps/pubgm/1599546071746KqkIhrzG.png"
      },
      {
        id: 9,
        mainAmount: 985,
        bonusAmount: 0,
        price: 173000,
        currency: "so'm",
        oldPrice: 1,
        popular: false,
        image: "https://cdn.midasbuy.com/images/apps/pubgm/1599546071746KqkIhrzG.png"
      },
      {
        id: 10,
        mainAmount: 1320,
        bonusAmount: 0,
        price: 235000,
        currency: "so'm",
        oldPrice: 1,
        popular: false,
        image: "https://cdn.midasbuy.com/images/apps/pubgm/1599546071746KqkIhrzG.png"
      },
      {
        id: 11,
        mainAmount: 1800,
        bonusAmount: 0,
        price: 289000,
        currency: "so'm",
        oldPrice: 1,
        popular: false,
        image: "https://cdn.midasbuy.com/images/apps/pubgm/1599546071746KqkIhrzG.png"
      },
      {
        id: 12,
        mainAmount: 3850,
        bonusAmount: 0,
        price: 559000,
        currency: "so'm",
        oldPrice: 1,
        popular: false,
        image: "https://cdn.midasbuy.com/images/apps/pubgm/1599546071746KqkIhrzG.png"
      },
      {
        id: 13,
        mainAmount: 8100,
        bonusAmount: 0,
        price: 1140000,
        currency: "so'm",
        oldPrice: 1,
        popular: false,
        image: "https://cdn.midasbuy.com/images/apps/pubgm/1599546071746KqkIhrzG.png"
      },
  ];

  return (
    <div className="shop-container">
      {/* <Header /> */}
      <div className="shop-header">
        <h1>Currency Shop</h1>
      </div>
      <motion.div className="shop-cards-grid" initial="hidden" animate="visible">
        {data.map((card, index) => (
          <motion.div
            className="shop-card"
            key={card.id}
            variants={cardVariants}
            custom={index}
            initial="hidden"
            animate="visible"
          >
            {card.popular && (
              <motion.div className="shop-popular-tag" variants={popularTagVariants} animate="animate">
                Mashhur
              </motion.div>
            )}
            <div className="shop-card-img">
              <img src={card.image} alt="Currency" />
            </div>
            <div className="shop-card-content">
              <div className="shop-currency-amount">
                <img
                  src="https://cdn.midasbuy.com/images/uc-small.bc30c95b.png"
                  alt="Currency icon"
                />
                {card.mainAmount} {card.bonusAmount > 0 ? "+" + card.bonusAmount : ""}
              </div>
              {card.bonusAmount > 0 && <div className="shop-bonus">+{card.bonusAmount}</div>}
              <div className="shop-price">{card.price} {card.currency}</div>
              <div className="shop-old-price">{card.oldPrice} {card.currency}</div>
              <button className="shop-buy-btn">Sotib olish</button>
            </div>
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
};

export default UcShop;
