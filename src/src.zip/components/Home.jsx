import React, { useState } from 'react';
import '../css/Bonus.css'; // Importing CSS for styling
import { motion } from "framer-motion";
import LoadingSpinner from './Loading'

const Bonus = () => {

  return (
  <LoadingSpinner />
  );
};

export default Bonus;