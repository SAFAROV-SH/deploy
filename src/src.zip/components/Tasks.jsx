import { motion } from 'framer-motion';

const Tasks = () => {
    const tasks = [
        {
            id: 1,
            title: 'Instagram profili',
            description: '50 bonus olish uchun Instagram profilingizni ulang',
            icon: 'fab fa-instagram',
            completed: false,
            type: 'instagram',
        },
        {
            id: 2,
            title: 'Telegram kanali',
            description: '30 bonus olish uchun Telegram kanaliga a\'zo bo\'ling',
            icon: 'fab fa-telegram-plane',
            completed: false,
            type: 'telegram',
        },
        {
            id: 3,
            title: 'Uc Servis',
            description: '30 bonus olish uchun Telegram kanaliga a\'zo bo\'ling',
            icon: 'fab fa-telegram-plane',
            completed: false,
            type: 'telegram',
        },
        {
            id: 4,
            title: 'Facebook profili',
            description: '40 bonus olish uchun Facebook profilingizni ulang',
            icon: 'fab fa-youtube',
            completed: true,
            type: 'youtube',
        },
    ];

    const completedTasks = tasks.filter(task => task.completed).length;
    const totalTasks = tasks.length;

    return (
        <div className="content-container">
            <h2>Vazifalar</h2>
            <p>Ijtimoiy tarmoqlarni ulash orqali bonuslar oling</p>
            <div className="social-tasks">
                {tasks.map(task => (
                    <motion.div
                        key={task.id}
                        className={`social-task-item ${task.completed ? 'completed' : ''}`}
                        animate={{
                            opacity: task.completed ? 1 : 0.9,
                            boxShadow: task.completed ? "none" : "0 0 15px rgba(255, 255, 255, 0.8)",
                        }}
                        transition={{
                            duration: 1.5,
                            repeat: task.completed ? 0 : Infinity,
                            repeatType: "loop",
                            ease: "easeInOut",
                        }}
                    >
                        <div className={`social-task-icon ${task.type}`}>
                            <motion.i
                                className={task.icon}
                                animate={{
                                    rotate: task.type === 'telegram' ? [0, 5, -5, 0] : 0, // Aylanish animatsiyasi
                                }}
                                transition={{
                                    duration: 1.5,
                                    repeat: Infinity,
                                    repeatType: "loop",
                                    ease: "easeInOut",
                                }}
                            ></motion.i>
                        </div>
                        <div className="social-task-info">
                            <h3>{task.title}</h3>
                            <p>{task.description}</p>
                        </div>
                        <div className="social-task-action">
                            {task.completed ? (
                                <i className="fas fa-check-circle"></i>
                            ) : (
                                <i className="fas fa-chevron-right"></i>
                            )}
                        </div>
                    </motion.div>
                ))}
            </div>
            <div className="task-bonus-card">
                <div className="task-bonus-icon">
                    <motion.i
                        className="fas fa-gift"
                        animate={{
                            scale: [1, 1.2, 1],
                            opacity: [1, 0.8, 1],
                        }}
                        transition={{
                            duration: 1.5,
                            repeat: Infinity,
                            repeatType: "loop",
                            ease: "easeInOut",
                        }}
                    ></motion.i>
                </div>
                <div className="task-bonus-info">
                    <h3>Barcha vazifalarni bajaring!</h3>
                    <p>Barcha ijtimoiy tarmoqlarni ulab, qo'shimcha 100 bonus oling</p>
                    <div className="task-progress-bar">
                        <div className="task-progress-fill" style={{ width: `${(completedTasks / totalTasks) * 100}%` }}></div>
                    </div>
                    <div className="task-progress-info">
                        <span>{completedTasks}/{totalTasks} vazifa bajarildi</span>
                        <span>Qoldi: {totalTasks - completedTasks} ta</span>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Tasks;
