const Withdraw = () => {

    return (
        <div className="content-container">
            <h2>Pul yechish</h2>
            <p>Bonuslarni pulga almashtiring</p>
            <div className="balance-box">
              <h3>Joriy balans</h3>
              <p className="balance">1250 bonus</p>
            </div>
            <div className="withdraw-form">
              <label>Miqdor</label>
              <input type="number" placeholder="Miqdorni kiriting" />
              <label>To'lov usuli</label>
              <select>
                <option>Click</option>
                <option>Payme</option>
                <option>UzCard</option>
              </select>
              <label>Hamyon raqami</label>
              <input type="text" placeholder="Hamyon raqamini kiriting" />
              <button className="withdraw-button">Pul yechish</button>
            </div>
          </div>
    );
};

export default Withdraw;